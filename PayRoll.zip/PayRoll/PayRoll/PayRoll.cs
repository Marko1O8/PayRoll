﻿/*Program Name: Payroll
 Date: 1/31/2022
Programer Name: Marko Miserda

Program Description: The program shows you the different type of employees you have and how they are paided.
If it is the employees birthday during the month of payroll they will receive a $100 bonus (polymorphically).

Inputs: FirstName, LastName, SocialSecurityNumber, month, day, year, WeeeklySalary, HourlyWage, HoursWorked, GrossSales, CommissionRate, BaseSalary, Wage, Piece

Outputs: FirstName, LastName, SocialSecurityNumber, month, day, year, WeeeklySalary, HourlyWage, HoursWorked, GrossSales, CommissionRate, BaseSalary,
Birthday Bonus, Earnings, Salary Increase, TypeOfEmployee, WagePerPiece, Pieces

Test Data: Employees processed individually:

salaried employee: John Smith
social security number: 111-11-1111
Birth Day: 9/22/1999
weekly salary: $800.00
earned: $800.00

hourly employee: Karen Price
social security number: 222-22-2222
Birth Day: 6/19/1989
hourly wage: $16.75
hours worked: 40.00
earned: $670.00

commission employee: Sue Jones
social security number: 333-33-3333
Birth Day: 2/7/1996
gross sales: $10,000.00
commission rate: 0.06
earned: $600.00

base-salaried commission employee: Bob Lewis
social security number: 444-44-4444
Birth Day: 10/26/1993
gross sales: $5,000.00
commission rate: 0.04
base salary: $300.00
earned: $500.00

Piece Worker: Phil Pond
social security number: 555-55-5555
Birth Day: 2/13/1995
Wage per piece: $10.75
Pieces made: 200
earned: $2,150.00

Employees processed polymorphically:

salaried employee: John Smith
social security number: 111-11-1111
Birth Day: 9/22/1999
weekly salary: $800.00
earned: $800.00

hourly employee: Karen Price
social security number: 222-22-2222
Birth Day: 6/19/1989
hourly wage: $16.75
hours worked: 40.00
earned: $670.00

commission employee: Sue Jones
social security number: 333-33-3333
Birth Day: 2/7/1996
gross sales: $10,000.00
commission rate: 0.06
Birthday Bonus: $100.00
earned: $700.00

base-salaried commission employee: Bob Lewis
social security number: 444-44-4444
Birth Day: 10/26/1993
gross sales: $5,000.00
commission rate: 0.04
base salary: $300.00
new base salary with 10% increase is: $330.00
earned: $530.00

Piece Worker: Phil Pond
social security number: 555-55-5555
Birth Day: 2/13/1995
Wage per piece: $10.75
Pieces made: 200
Birthday Bonus: $100.00
earned: $2,250.00

Employee 0 is a PayRoll.SalariedEmployee
Employee 1 is a PayRoll.HourlyEmployee
Employee 2 is a PayRoll.CommissionEmployee
Employee 3 is a PayRoll.BasePlusCommissionEmployee
Employee 4 is a PayRoll.PieceWorker
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayRoll
{
    class PayRoll
    {
        static void Main(string[] args)
        {
            var salariedEmployee = new SalariedEmployee("John", "Smith",
                "111-11-1111", 09, 22, 1999, 800.00M);
            var hourlyEmployee = new HourlyEmployee("Karen", "Price",
                "222-22-2222", 06, 19, 1989, 16.75M, 40.0M);
            var commissionEmployee = new CommissionEmployee("Sue", "Jones",
                "333-33-3333", 02, 07, 1996, 10000.00M, .06M);
            var basePlusCommissionEmployee =
                new BasePlusCommissionEmployee("Bob", "Lewis",
                "444-44-4444", 10, 26, 1993, 5000.00M, .04M, 300.00M);
            var pieceWorker = new PieceWorker("Phil", "Pond",
                "555-55-5555", 02,13,1995, 10.75M, 200);

            DateTime dt = DateTime.Now;

            Console.WriteLine("Employees processed individually:\n");

            Console.WriteLine($"{salariedEmployee}\nearned: " +
                $"{salariedEmployee.Earnings():C}\n");
            Console.WriteLine(
                $"{hourlyEmployee}\nearned: {hourlyEmployee.Earnings():C}\n");
            Console.WriteLine($"{commissionEmployee}\nearned: " +
                $"{commissionEmployee.Earnings():C}\n");
            Console.WriteLine($"{basePlusCommissionEmployee}\nearned: " +
                $"{basePlusCommissionEmployee.Earnings():C}\n");
            Console.WriteLine($"{pieceWorker}\nearned: " +
               $"{pieceWorker.Earnings():C}\n");

            var employees = new List<Employee>() {salariedEmployee,
            hourlyEmployee, commissionEmployee, basePlusCommissionEmployee, pieceWorker};

            Console.WriteLine("Employees processed polymorphically:\n");

            foreach (var currentEmployee in employees)
            {
                Console.WriteLine(currentEmployee);

                if (currentEmployee is BasePlusCommissionEmployee)
                {
                    var employee = (BasePlusCommissionEmployee)currentEmployee;

                    employee.BaseSalary *= 1.10M;
                    Console.WriteLine("new base salary with 10% increase is: " +
                        $"{employee.BaseSalary:C}");
                }
                if (currentEmployee.Month == dt.Month)
                {
                    Console.WriteLine("Birthday Bonus: $100.00");
                    Console.WriteLine($"earned: {currentEmployee.Earnings() + 100:C}\n");
                }
                else
                    Console.WriteLine($"earned: {currentEmployee.Earnings():C}\n");

            }
            for (int j = 0; j < employees.Count; j++)
            {
                Console.WriteLine(
                    $"Employee {j} is a {employees[j].GetType()}");
            }

            Console.ReadKey();
        }
    }

}