﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayRoll
{
    public class PieceWorker : Employee
    {
        private decimal wage;
        private int piece;

        public PieceWorker(string firstName, string lastName,
            string socialSecurityNumber, int month, int day, int year, decimal wage, int piece)
            : base(firstName, lastName, socialSecurityNumber, month, day, year)
        {
            Wage = wage;
            Piece = piece;
        }
        public decimal Wage
        {
            get
            {
                return wage;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        value, $"{nameof(Wage)} must be >= 0");
                }
                wage = value;
            }
        }
        public int Piece
        {
            get
            {
                return piece;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        value, $"{nameof(Piece)} must be >= 0");
                }
                piece = value;
            }
        }
        public override decimal Earnings()
        {
            return Wage * Piece;
        }
        public override string ToString() =>
           $"Piece Worker: {base.ToString()}\n" +
           $"Wage per piece: {Wage:C}\nPieces made: {Piece}";
    }
}
