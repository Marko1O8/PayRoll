﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayRoll
{
    public class SalariedEmployee : Employee
    {
        private decimal weeklySalary;

        public SalariedEmployee(string firstName, string lastName,
            string socialSecurityNumber, int month, int day, int year, decimal weeklySalary)
            : base(firstName, lastName, socialSecurityNumber, month, day, year)
        {
            WeeklySalary = weeklySalary;
        }

        public decimal WeeklySalary
        {
            get
            {
                return weeklySalary;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        value, $"{nameof(WeeklySalary)} must be >=0");
                }
                weeklySalary = value;
            }
        }
        public override decimal Earnings() => WeeklySalary;

        public override string ToString() =>
            $"salaried employee: {base.ToString()}\n" +
            $"weekly salary: {WeeklySalary:C}";

    }
}
